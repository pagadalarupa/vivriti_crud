package com.example.vivriti;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VivritiTechnologiesUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(VivritiTechnologiesUserApplication.class, args);
		
		System.out.println("Test");
	}

	
	
}
