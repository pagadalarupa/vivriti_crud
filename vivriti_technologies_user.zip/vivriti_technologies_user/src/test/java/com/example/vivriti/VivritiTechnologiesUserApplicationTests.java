package com.example.vivriti;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VivritiTechnologiesUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
